import adsk.core as core
import adsk.fusion as fusion
import adsk
import os
import shutil
import time
import traceback
from ...lib import fusionAddInUtils as futil
from ... import config

from . import Add

app = core.Application.get()
ui = app.userInterface


# TODO *** Specify the command identity information. ***
CMD_ID = f'{config.COMPANY_NAME}_{config.ADDIN_NAME}_cmdDialog'
CMD_NAME = 'Ramp_Builder'
CMD_Description = 'BUILD THAT RAMP!!'

# Specify that the command will be promoted to the panel.
IS_PROMOTED = True

# TODO *** Define the location where the command button will be created. ***
# This is done by specifying the workspace, the tab, and the panel, and the
# command it will be inserted beside. Not providing the command to position it
# will insert it at the end.
WORKSPACE_ID = 'FusionSolidEnvironment'
PANEL_ID = 'SolidScriptsAddinsPanel'
COMMAND_BESIDE_ID = 'ScriptsManagerCommand'

_handlers = []
# Resource location for command icons, here we assume a sub folder in this directory named "resources".
ICON_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', '')

# Local list of event handlers used to maintain a reference so
# they are not released and garbage collected.
local_handlers = []

#
# FUNCTIONS
#

#
# Working functions for building the ramp
#
def Temp_files_create(file_name, ID):
    # Ensure source_dir is a directory path, not a file path like you were passing
    # in the command_execute function's original call.
    # The file_name passed to this function should be just the file name, e.g., "Landing.f3d"
    source_dir = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets"
    destination_dir = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp"

    src_path = os.path.join(source_dir, os.path.basename(file_name)) # Use os.path.basename to get just the filename
    dest_path = os.path.join(destination_dir, f"{ID}_{os.path.basename(file_name)}")

    try:
        shutil.copy(src_path, dest_path)
    except FileNotFoundError:
        if ui:
            ui.messageBox(f'Error: Source file not found: {src_path}')
    except PermissionError:
        if ui:
            ui.messageBox(f'Error: Permission denied when copying to {dest_path}.')
    except Exception as e:
        if ui:
            ui.messageBox(f'An unexpected error occurred while copying file: {e}')

# Executed when add-in is run.
def start():
    # Create a command Definition.
    cmd_def = ui.commandDefinitions.addButtonDefinition(CMD_ID, CMD_NAME, CMD_Description, ICON_FOLDER)

    # Define an event handler for the command created event. It will be called when the button is clicked.
    futil.add_handler(cmd_def.commandCreated, command_created)

    # ******** Add a button into the UI so the user can run the command. ********
    # Get the target workspace the button will be created in.
    workspace = ui.workspaces.itemById(WORKSPACE_ID)

    # Get the panel the button will be created in.
    panel = workspace.toolbarPanels.itemById(PANEL_ID)

    # Create the button command control in the UI after the specified existing command.
    control = panel.controls.addCommand(cmd_def, COMMAND_BESIDE_ID, False)

    # Specify if the command is promoted to the main toolbar.
    control.isPromoted = IS_PROMOTED


# Executed when add-in is stopped.
def stop():
    # Get the various UI elements for this command
    workspace = ui.workspaces.itemById(WORKSPACE_ID)
    panel = workspace.toolbarPanels.itemById(PANEL_ID)
    command_control = panel.controls.itemById(CMD_ID)
    command_definition = ui.commandDefinitions.itemById(CMD_ID)

    # Delete the button command control
    if command_control:
        command_control.deleteMe()

    # Delete the command definition
    if command_definition:
        command_definition.deleteMe()


# Function that is called when a user clicks the corresponding button in the UI.
# This defines the contents of the command dialog and connects to the command related events.
def command_created(args: core.CommandCreatedEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Created Event')

    # https://help.autodesk.com/view/fusion360/ENU/?contextId=CommandInputs
    inputs = args.command.commandInputs

    # TODO Define the dialog for your command by adding different inputs to the command.

    # Create a simple text box input.

    # Create a value input field and set the default using 1 unit of the default length unit.
    # You had a valueInput here that wasn't used, and a textbox for height
    # defaultLengthUnits = app.activeProduct.unitsManager.defaultLengthUnits
    # default_value = core.ValueInput.createByString('1')
    inputs.addTextBoxCommandInput('num_sections', 'How many sections of Ramp?', "",1, False)
    inputs.addTextBoxCommandInput('ramp_name', 'Ramp Build? (Shorthand)', '', 8, False)
    inputs.addTextBoxCommandInput('height', 'Height of first box?', '', 8, False) # This is a TextBox, not a ValueInput

    # TODO Connect to the events that are needed by this command.
    futil.add_handler(args.command.execute, command_execute, local_handlers=local_handlers)
    futil.add_handler(args.command.inputChanged, command_input_changed, local_handlers=local_handlers)
    futil.add_handler(args.command.executePreview, command_preview, local_handlers=local_handlers)
    futil.add_handler(args.command.validateInputs, command_validate_input, local_handlers=local_handlers)
    futil.add_handler(args.command.destroy, command_destroy, local_handlers=local_handlers)

part_map = {
    "8ft": {
        'first_ramp_to_ramp': "FFP_5o_8ft.f3d",
        'first_ramp_to_flat': "FP_5o_8ft_5o.f3d",
        'ramp_to_ramp': "FP_8ft.f3d",
        'ramp_to_flat': "FP_8ft_5o.f3d",
        'flat_to_ramp': "FP_5o_8ft.f3d",
        'ending_ramp_from_ramp': "FP_8ft.f3d",
        'ending_ramp_from_flat': "FP_5o_8ft.f3d",
        'flat_to_ramp_to_flat': "FP_5o_8ft_5o.f3d"
    },
    "12ft": {
        'first_ramp_to_ramp': "FP_5o_12ft.f3d",
        'first_ramp_to_flat': "FP_5o_12ft_5o.f3d",
        'ramp_to_ramp': "FP_12ft.f3d",
        'ramp_to_flat': "FP_12ft_5o.f3d",
        'flat_to_ramp': "5o_12ft.f3d", ##
        'ending_ramp_from_ramp': "FP_12ft.f3d",
        'ending_ramp_from_flat': "5o_12ft.f3d", #
        'flat_to_ramp_to_flat': "FP_5o_12ft_5o.f3d"
    },
    "16ft": {
        'first_ramp_to_ramp': "FP_5o_16ft.f3d",
        'first_ramp_to_flat': "FP_5o_16ft_5o.f3d",
        'ramp_to_ramp': "FP_16ft.f3d",
        'ramp_to_flat': "FP_16ft_5o.f3d",
        'flat_to_ramp': "5o_16ft.f3d", #
        'ending_ramp_from_ramp': "FP_16ft.f3d",
        'ending_ramp_from_flat': "5o_16ft.f3d", #
        'flat_to_ramp_to_flat': "FP_5o_16ft_5o.f3d"
    },
    "LAN": {
        "landing": "Landing 4x4.f3d"
    },
    "TL": {
        "left_turn": "Left Turn 4x4.f3d"
    },
    "TR": {
        "right_turn": "Right Turn 4x4.f3d"
    },
    "UTURNR": {
        "U_turn": "UTurn Right.f3d"
    },
    "UTURNL": {
        "U_turn": "UTurn Left.f3d"
    }
    }

def get_file_name(current_part, prev_part, next_part, is_first, is_last, ramp, flat):
    """
    Determines the correct filename for a given part based on its context.

    Args:
        current_part (str): The part being processed.
        prev_part (str or None): The part before the current one, or None if it's the first.
        next_part (str or None): The part after the current one, or None if it's the last.
        is_first (bool): True if the part is the first in the list.
        is_last (bool): True if the part is the last in the list.
        ramp (list): A list of strings representing ramp parts.
        flat (list): A list of strings representing flat parts.

    Returns:
        str: The filename corresponding to the part and its context.
    """
    if current_part == "LAN":
        return part_map["LAN"]["landing"]
    if current_part == "TL":
        return part_map["TL"]["left_turn"]
    if current_part == "TR":
        return part_map["TR"]["right_turn"]
    if current_part == "UTR":
        return part_map["UTURNL"]["U_turn"]
    if current_part == "UTL":
        return part_map["UTURNR"]["U_turn"]
    if is_first:
        if next_part in flat:
            return part_map[current_part]['first_ramp_to_flat']
        elif next_part in ramp:
            return part_map[current_part]['first_ramp_to_ramp']
    elif is_last:
        if prev_part in flat:
            return part_map[current_part]['ending_ramp_from_flat']
        elif prev_part in ramp:
            return part_map[current_part]['ending_ramp_from_ramp']
    else: # It's a middle part
        if prev_part in flat and next_part in flat:
            return part_map[current_part]['flat_to_ramp_to_flat']
        elif prev_part in flat and next_part in ramp:
            return part_map[current_part]['flat_to_ramp']
        elif prev_part in ramp and next_part in flat:
            return part_map[current_part]['ramp_to_flat']
        elif prev_part in ramp and next_part in ramp:
            return part_map[current_part]['ramp_to_ramp']
    if current_part not in part_map:
        ui.messageBox(f"Ramp part not found: {current_part}")
        return None
        
    
    ui.messageBox(f"Could not determine filename for part: {current_part} at index")
    return None
# This event handler is called when the user clicks the OK button in the command dialog or
# is immediately called after the created event not command inputs were created for the dialog.
def command_execute(args: core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Execute Event')

    # Get a reference to the application and user interface.
    design = app.activeProduct
    if not design:
        ui.messageBox('No active design found. Please open a design before running this command.')
        return

    #
    # Inputs
    #
    inputs = args.command.commandInputs
    num_sections_input = inputs.itemById('num_sections')
    ramp_name_input = inputs.itemById('ramp_name')
    height_input_cmd = inputs.itemById('height') # Renamed to avoid confusion with the value itself

    # Get the actual string value from the input
    height_value_str = height_input_cmd.text

    # List making for parts
    ramp_name_text = ramp_name_input.text
    ramp_parts = [name.strip() for name in ramp_name_text.split(',') if name.strip()]

    # test to check if sections to parts is equal
    if len(ramp_parts) != int(num_sections_input.text):
        ui.messageBox('The number of ramp sections does not match the number of parts provided. Please check your inputs.')
        return
    
    #
    # Create file parts
    #
    temp_folder_path = os.path.join(r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets", "Temp")
    if not os.path.exists(temp_folder_path):
        os.makedirs(temp_folder_path, exist_ok=True)


    ramp="8ft","12ft","16ft"
    flat="TL","TR","LAN","UTL","UTR"

    # create COPY/TEMP files for building the ramp
    ramp_parts_folder = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets"
    ############## ALL THESE SHOULD CHECK BEFORE AND AFTER

    for idx, part in enumerate(ramp_parts):
        # Determine the previous and next parts, handling the beginning and end of the list
        prev_part = ramp_parts[idx - 1] if idx > 0 else None
        next_part = ramp_parts[idx + 1] if idx < len(ramp_parts) - 1 else None
        
        # Check if the current part is the first or last
        is_first = (idx == 0)
        is_last = (idx == len(ramp_parts) - 1)
        
        # Get the filename using our new function
        file_name = get_file_name(part, prev_part, next_part, is_first, is_last, ramp, flat)
        
        # If a valid filename was found, create the file
        if file_name:
            Temp_files_create(file_name, idx)


        """
        #
        # First
        #
        # First Ramp going into a another ramp OR comign off a flat

        if (idx == 0 and part in ramp):
            if (part == "8ft"):
                Temp_files_create("FP_5o_8ft.f3d",idx)
            elif (part == "12ft"):
                Temp_files_create("FP_5o_12ft.f3d",idx)
            elif (part == "16ft"):
                Temp_files_create("FP_5o_16ft.f3d",idx)
            else:
                ui.messageBox(f"Ramp part not found: {part}")
        # First ramp going in to flat OR flat RAMP flat
        elif (idx == 0 and part in ramp and ramp_parts[idx+1] in flat or (part in ramp and ramp_parts[idx-1] in flat and ramp_parts[idx+1] in flat)):
            if (part == "8ft"):
                Temp_files_create("FP_5o_8ft_5o.f3d",idx)
            elif (part == "12ft"):
                Temp_files_create("FP_5o_12ft_5o.f3d",idx)
            elif (part == "16ft"):
                Temp_files_create("FP_5o_16ft_5o.f3d",idx)
            else:
                ui.messageBox(f"Ramp part not found: {part}")
        #
        # Ending
        #
        # Ramp coming from ramp to end ############################################################### CHECK DIS ### ned change to endnign dessing LAST
        elif (idx+1 == len(ramp_parts) and ramp_parts[idx-1] in ramp):
            if (part == "8ft"):
                Temp_files_create("FP_8ft.f3d",idx)
            elif (part == "12ft"):
                Temp_files_create("FP_12ft.f3d",idx)
            elif (part == "16ft"):
                Temp_files_create("FP_16ft.f3d",idx)
            else:
                ui.messageBox(f"Ramp part not found: {part}")
        elif (idx+1 == len(ramp_parts) and ramp_parts[idx-1] in flat):
            ui.messageBox(f"{(idx+1 == len(ramp_parts) and ramp_parts[idx-1] in flat)}")
            if (part == "8ft"):
                Temp_files_create("5o_8ft.f3d",idx)
            elif (part == "12ft"):
                Temp_files_create("5o_12ft.f3d",idx)
            elif (part == "16ft"):
                Temp_files_create("5o_16ft.f3d",idx)
            else:
                ui.messageBox(f"Ramp part not found: {part}")
        #
        # RAMP to flats
        #
        # ramp coming from flat and part after is ramp
        # next is landing
        elif (part in ramp and ramp_parts[idx+1] in flat):
            if (part == "8ft"):
                Temp_files_create("FP_8ft_5o.f3d",idx)
            elif (part == "12ft"):
                Temp_files_create("FP_12ft_5o.f3d",idx)
            elif (part == "16ft"):
                Temp_files_create("FP_16ft_5o.f3d",idx)
            else:
                ui.messageBox(f"Ramp part not found: {part}")
        elif (part == "LAN"):
            Temp_files_create("Landing 4x4.f3d",idx)
        # Ramp coming from landing
        elif (part in ramp and ramp_parts[idx-1] in flat):
            if (part == "8ft"):
                Temp_files_create("5o_8ft.f3d",idx)
            elif (part == "12ft"):
                Temp_files_create("5o_12ft.f3d",idx)
            elif (part == "16ft"):
                Temp_files_create("5o_16ft.f3d",idx)
            else:
                ui.messageBox(f"Ramp part not found: {part}")
        #
        # Ramps to ramps
        #
        # Ramp coming from ramp to ramp
        elif (part in ramp and ramp_parts[idx+1] in ramp and ramp_parts[idx-1] in ramp):
            if (part == "8ft"):
                Temp_files_create("FP_8ft.f3d",idx)
            elif (part == "12ft"):
                Temp_files_create("FP_12ft.f3d",idx)
            elif (part == "16ft"):
                Temp_files_create("FP_16ft.f3d",idx)
            else:
                ui.messageBox(f"Ramp part not found: {part}")

        elif (part == "LAN"):
            Temp_files_create("Landing 4x4.f3d",idx)
        """
    # export height
    try:
        # Define the full path for the height file
        height_file_name = f"{height_value_str}.h" # Using the actual string value
        height_file_path = os.path.join(temp_folder_path, height_file_name)

        with open(height_file_path, 'w') as f:
            for i in ramp_parts:
                f.write(f"{i}\n")
    except Exception as e:
        ui.messageBox(f'Error saving height file: {traceback.format_exc()}')

    #
    # BUILD THE RAMP
    #temp_destination_dir = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp"
    #for f in os.listdir(temp_destination_dir):
    #    os.remove(os.path.join(temp_destination_dir, f))


# This event handler is called when the command needs to compute a new preview in the graphics window.
def command_preview(args: core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Preview Event')
    inputs = args.command.commandInputs


# This event handler is called when the user changes anything in the command dialog
# allowing you to modify values of other inputs based on that change.
def command_input_changed(args: core.InputChangedEventArgs):
    changed_input = args.input
    inputs = args.inputs

    # General logging for debug.
    futil.log(f'{CMD_NAME} Input Changed Event fired from a change to {changed_input.id}')


# This event handler is called when the user interacts with any of the inputs in the dialog
# which allows you to verify that all of the inputs are valid and enables the OK button.
def command_validate_input(args: core.ValidateInputsEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Validate Input Event')

    inputs = args.inputs
    
    # You need to check the 'height' input, not 'value_input' which doesn't exist.
    # Also, ensure it's a valid number if you expect a numeric height.
    height_input_cmd = inputs.itemById('height')
    if height_input_cmd and height_input_cmd.text:
        try:
            # Attempt to convert to float to validate it's a number
            float(height_input_cmd.text)
            args.areInputsValid = True
        except ValueError:
            args.areInputsValid = False # Not a valid number
            # You might want to provide feedback to the user here as well
    else:
        args.areInputsValid = False # Input is empty or not found

    # Remove or update this if you're not using 'value_input'
    # valueInput = inputs.itemById('value_input')
    # if valueInput and valueInput.value >= 0:
    #     args.areInputsValid = True
    # else:
    #     args.areInputsValid = False
        

# This event handler is called when the command terminates.
def command_destroy(args: core.CommandEventArgs):
    # General logging for debug.
    futil.log(f'{CMD_NAME} Command Destroy Event')

    global local_handlers
    local_handlers = []