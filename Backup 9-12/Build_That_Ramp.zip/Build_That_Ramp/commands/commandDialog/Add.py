# Fusion360API Python script

import traceback
import adsk.core as core
import adsk.fusion as fusion
import os

import pathlib
THIS_DIR = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp"
temp_destination_dir = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp"
parts_list_files = sorted([os.path.join(temp_destination_dir, f) for f in os.listdir(temp_destination_dir) if f.endswith('.f3d')])
    
def run(context):
    ui: core.UserInterface = None
    try:
        app: core.Application = core.Application.get()
        ui = app.userInterface

        paths = parts_list_files

        import_f3ds(paths)

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

def import_f3ds(paths: list[str]) -> None:
    app: core.Application = core.Application.get()
    try:
        des: fusion.Design = app.activeProduct
        root: fusion.Component = des.rootComponent

        importMgr: core.ImportManager = app.importManager

        for path in paths:
            importOpt: core.FusionArchiveImportOptions = importMgr.createFusionArchiveImportOptions(
                path,
            )
            importMgr.importToTarget(importOpt , root)
    except:
        app.log('Failed:\n{}'.format(traceback.format_exc())) 