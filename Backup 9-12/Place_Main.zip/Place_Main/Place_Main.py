import adsk.core
import adsk.fusion
import traceback
import os
import math
import re
import csv

#
# Global dictionary defining required lumber and deck boards for each block type
# NEEDS UTURNS
blocks = {
    "8ft": {
    "2x6x8": 5,
    "2x4x8": 4,
    "8ft Deck Boards": 11 # 9 for decking 2 for rails
    },

    "12ft": {
    "2x6x12": 3,
    "2x6x8": 2,
    "2x4x12": 4,
    "8ft Deck Boards": 13, # Decking
    "12ft Deck Boards": 2 # Rails
    },
    "16ft": {
    "2x6x16": 3,
    "2x6x8": 2,
    "2x4x16": 4,
    "8ft Deck Boards": 18, # Decking
    "16ft Deck Boards": 2 # Rails
    },
    "Turn": {
    "2x6x8": 3,
    "2x4x10": 2,
    "8ft Deck Boards": 5, # Decking
    "10ft Deck Boards": 2 # Rails
    },
    "Landing": {
    "2x6x8": 3,
    "2x4x8": 2,
    "8ft Deck Boards": 6, # 5 for decking 1 for rails
    },
    "UTurn": {
    "2x6x10": 3,
    "2x6x8": 2,
    "2x4x10": 1,
    "2x4x8": 1,
    "10ft Deck Boards": 2, # Rails
    "8ft Deck Boards": 10, # Decking
    }
}


def _import_block(app: adsk.core.Application, end_type: str,part):
    """
    Helper function to import a specific .f3d file and rename it.

    Args:
        app (adsk.core.Application): The Fusion 360 application object.
        end_type (str): The type of block to import (e.g., "Block", "Paver"). 
                        This will also be used as the new name.
    """
    block_paths = {
        "Block": r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Deck Block.f3d",
        "Paver": r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Paver.f3d",
        # Add more block types and their paths here
    }

    try:
        path = block_paths.get(end_type)
        if not path:
            app.log(f'Failed: No path found for end_type: {end_type}')
            return

        des: adsk.fusion.Design = app.activeProduct
        root: adsk.fusion.Component = des.rootComponent
        importMgr: adsk.core.ImportManager = app.importManager
        importOpt: adsk.core.FusionArchiveImportOptions = importMgr.createFusionArchiveImportOptions(path)

        # The importToTarget method returns the newly created component
        new_component = importMgr.importToTarget(importOpt, root)

        # Check if the component was successfully created and then rename it
        if new_component:
            new_component.name = end_type
            app.log(f'Successfully imported and renamed component to: {end_type}')
        else:
            app.log('Failed: Component was not created during import.')
            
    except:
        app.log('Failed to import component:\n{}'.format(traceback.format_exc()))

def dicts_to_csv(data: list[dict], filename: str):
    app = adsk.core.Application.get()
    ui = app.userInterface
    """
    Converts a list of dictionaries to a CSV file.

    Each dictionary in the list is treated as a row, with the keys of the
    first dictionary used as the header row.

    Args:
        data (list[dict]): A list of dictionaries to write to the CSV file.
        filename (str): The name of the output CSV file (e.g., 'output.csv').
    """
    if not data:
        print("The input data is empty. No CSV file will be created.")
        return

    try:
        # Get the headers from the keys of the first dictionary
        headers = data[0].keys()

        # Ensure the filename has a .csv extension
        if not filename.lower().endswith('.csv'):
            filename += '.csv'

        with open(filename, 'w', newline='') as csvfile:
            # Create a DictWriter object
            writer = csv.DictWriter(csvfile, fieldnames=headers)

            # Write the header row
            writer.writeheader()

            # Write the data rows
            writer.writerows(data)

        ui.messageBox(f"Successfully created '{filename}' with {len(data)} rows.")

    except IOError as e:
        ui.messageBox(f"I/O error({e.errno}): {e.strerror}")
    except Exception as e:
        ui.messageBox(f"An unexpected error occurred: {e}")

class box():
    def __init__(self, i_obj_input_name: adsk.fusion.Occurrence):
        self.occurrence = i_obj_input_name
        self.name = self.occurrence.name

    def get_occurrence(self):
        return self.occurrence

    def getBack(self,part):
        app = adsk.core.Application.get()
        ui = app.userInterface
        for child_occ in self.occurrence.childOccurrences:
            if part in child_occ.name:
                # Get the native body fromchild
                component = child_occ.component
                ui.messageBox(child_occ.name)
                if component.bRepBodies.count > 0:
                    #
                    # BRTUYRTE
                    #
                    native_body = component.bRepBodies.item(0)
                    
                    # Iterate through the faces
                    for face in native_body.faces:
                        if isinstance(face.geometry, adsk.core.Plane):
                            plane = adsk.core.Plane.cast(face.geometry)
                            if plane:
                                normal = plane.normal
                                ui.messageBox(f" BACK{normal.x} {normal.y} {normal.z}")
                                if normal.x <= -.9 and abs(normal.y) < 0.1 and abs(normal.z) < 0.1:
                                    #ui.messageBox(f" BACK{normal.x} {normal.y} {normal.z}")
                                    return face.createForAssemblyContext(child_occ)
        ui.messageBox("Back face not found")
        return None

    def getFront(self,part):
        # front face normal points in the positive X direction.
        app = adsk.core.Application.get()
        ui = app.userInterface
        for child_occ in self.occurrence.childOccurrences:
            if part in child_occ.name:
                component = child_occ.component
                if component.bRepBodies.count > 0:
                    # Get first body
                    native_body = component.bRepBodies.item(0)
                    
                    for face in native_body.faces:
                        if isinstance(face.geometry, adsk.core.Plane):
                            plane = adsk.core.Plane.cast(face.geometry)
                            if plane:
                                normal = plane.normal
                                if normal.x > .9 and abs(normal.y) < 0.1 and abs(normal.z) < 0.1:
                                    #ui.messageBox(f" FOPRUN{normal.x} {normal.y} {normal.z}")
                                    return face.createForAssemblyContext(child_occ)
        ui.messageBox("Front face not found")
        return None

    def getLeft(self,part):

        app = adsk.core.Application.get()
        ui = app.userInterface
        for child_occ in self.occurrence.childOccurrences:
            
            if part in child_occ.name:
                # Get the native body fromchild
                component = child_occ.component
                if component.bRepBodies.count > 0:
                    #
                    # BRTUYRTE
                    #
                    native_body = component.bRepBodies.item(0)
                    
                    # Iterate through the faces
                    for face in native_body.faces:
                        if isinstance(face.geometry, adsk.core.Plane):
                            plane = adsk.core.Plane.cast(face.geometry)
                            if plane:
                                normal = plane.normal
                                #ui.messageBox(f"{normal.x} {normal.y} {normal.z}")
                                if abs(normal.x) < 0.1 and normal.y <= -.9 and abs(normal.z) < 0.1:
                                    #ui.messageBox(f" LEFT{normal.x} {normal.y} {normal.z}")
                                    return face.createForAssemblyContext(child_occ)
        ui.messageBox("Left face not found")
        return None

    def getRight(self, part):
        app = adsk.core.Application.get()
        ui = app.userInterface
        # front face normal points in the positive X direction.
        for child_occ in self.occurrence.childOccurrences:
            if part in child_occ.name:
                component = child_occ.component
                if component.bRepBodies.count > 0:
                    # Get first body
                    native_body = component.bRepBodies.item(0)
                    
                    for face in native_body.faces:
                        if isinstance(face.geometry, adsk.core.Plane):
                            plane = adsk.core.Plane.cast(face.geometry)
                            if plane:
                                normal = plane.normal
                                if abs(normal.x) < 0.1 and normal.y <= .9 and abs(normal.z) < 0.1:
                                    return face.createForAssemblyContext(child_occ)
        ui.messageBox("Right face not found")
        return None

class post():
    def __init__(self, i_obj_input_name: adsk.fusion.Occurrence):
        self.occurrence = i_obj_input_name
        self.name = self.occurrence.name

    def getBottom(self,post_number,post_it):
        app = adsk.core.Application.get()
        ui = app.userInterface
        for child_occ in self.occurrence.childOccurrences:
            if post_it == "0":
                if "4x4:"+str(post_number) == child_occ.name:
                    #ui.messageBox("4x4:"+str(post_number))
                    # Get the native body from child
                    component = child_occ.component
                    if component.bRepBodies.count > 0:
                        #
                        # BRTUYRTE
                        #
                        native_body = component.bRepBodies.item(0)

                        # Iterate through the faces
                        for face in native_body.faces:
                            if isinstance(face.geometry, adsk.core.Plane):
                                plane = adsk.core.Plane.cast(face.geometry)
                                if plane:
                                    normal = plane.normal
                                    if abs(normal.x) < 0.1 and abs(normal.y) < 0.1 and normal.z == -1:
                                        #ui.messageBox(f"Face found {normal.x} {normal.y} {normal.z}")
                                        return face.createForAssemblyContext(child_occ)
            else:
                if "4x4 ("+str(post_it)+"):"+str(post_number) == child_occ.name:
                    #ui.messageBox("4x4 ("+str(post_it)+"):"+str(post_number))
                    # Get the native body from child
                    component = child_occ.component
                    if component.bRepBodies.count > 0:
                        #
                        # BRTUYRTE
                        #
                        native_body = component.bRepBodies.item(0)
                        #ui.messageBox("body")
                        # Iterate through the faces
                        for face in native_body.faces:
                            if isinstance(face.geometry, adsk.core.Plane):
                                plane = adsk.core.Plane.cast(face.geometry)
                                if plane:
                                    normal = plane.normal
                                    if abs(normal.x) < 0.1 and abs(normal.y) < 0.1 and normal.z == -1:
                                        return face.createForAssemblyContext(child_occ)
        return None
    def getTop(self,post_number,post_it):
        app = adsk.core.Application.get()
        ui = app.userInterface
        for child_occ in self.occurrence.childOccurrences:
            if post_it == "0":
                if "4x4:"+str(post_number) == child_occ.name:
                    
                    # Get the native body from child
                    component = child_occ.component
                    if component.bRepBodies.count > 0:
                        #
                        # BRTUYRTE
                        #
                        native_body = component.bRepBodies.item(0)

                        # Iterate through the faces
                        for face in native_body.faces:
                            if isinstance(face.geometry, adsk.core.Plane):
                                plane = adsk.core.Plane.cast(face.geometry)
                                if plane:
                                    normal = plane.normal
                                    if abs(normal.x) < 0.1 and abs(normal.y) < 0.1 and normal.z > 0.8:
                                        return face.createForAssemblyContext(child_occ)
            else:
                if "4x4 ("+str(post_it)+"):"+str(post_number) == child_occ.name:
                    # Get the native body from child
                    component = child_occ.component
                    if component.bRepBodies.count > 0:
                        #
                        # BRTUYRTE
                        #
                        native_body = component.bRepBodies.item(0)

                        # Iterate through the faces
                        for face in native_body.faces:
                            if isinstance(face.geometry, adsk.core.Plane):
                                plane = adsk.core.Plane.cast(face.geometry)
                                if plane:
                                    normal = plane.normal
                                    if abs(normal.x) < 0.1 and abs(normal.y) < 0.1 and normal.z > 0.8:
                                        return face.createForAssemblyContext(child_occ)
        return None
class block():
    def __init__(self, i_obj_input_name: adsk.fusion.Occurrence):
        self.occurrence = i_obj_input_name
        self.name = self.occurrence.name

    def name_get(self):
        return self.occurrence.name

    def getTop(self):
        app = adsk.core.Application.get()
        ui = app.userInterface
        # Get the native body fromchild
        component = self.occurrence.component
        if component.bRepBodies.count > 0:
            
            #
            # BRTUYRTE
            #
            native_body = component.bRepBodies.item(0)
            
            # Iterate through the faces
            for face in native_body.faces:
                if isinstance(face.geometry, adsk.core.Plane):
                    plane = adsk.core.Plane.cast(face.geometry)
                    if plane:
                        normal = plane.normal
                        if abs(normal.x) < 0.1 and abs(normal.y) < 0.1 and normal.z < 0.9:
                            return face.createForAssemblyContext(self.occurrence)
        return None

class Paver():
    def __init__(self, i_obj_input_name: adsk.fusion.Occurrence):
        self.occurrence = i_obj_input_name
        self.name = self.occurrence.name

    def name_get(self):
        return self.occurrence.name

    def getTop(self):
        app = adsk.core.Application.get()
        ui = app.userInterface
        component = self.occurrence.component
        if component.bRepBodies.count > 0:
            native_body = component.bRepBodies.item(0)
            
            for face in native_body.faces:
                if isinstance(face.geometry, adsk.core.Plane):
                    plane = adsk.core.Plane.cast(face.geometry)
                    if plane:
                        normal = plane.normal
                        # LOGIC
                        if abs(normal.x) < 0.1 and abs(normal.y) < 0.1 and normal.z > .9:
                            return face.createForAssemblyContext(self.occurrence)
        return None
def find_lowest_edge_on_face(face_proxy):
    """
    Finds the edge with the lowest Z-coordinate on a given BRepFaceProxy.
    Returns None if no suitable edge is found.
    """
    app = adsk.core.Application.get()
    ui = app.userInterface

    lowest_z = 999999.0  # Initialize with a very high value
    found_edge = None

    if not face_proxy:
        if ui:
            ui.messageBox("Error: Face proxy is None when trying to find lowest edge.", "Input Error")
        return None

    # Iterate through all the edges on the face.
    for edge in face_proxy.edges:
        # Check the Z-coordinate of the start vertex.
        start_vertex = edge.startVertex
        if start_vertex:
            start_point = start_vertex.geometry
            # ui.messageBox(f"Start Vertex: {start_point.x}, {start_point.y}, {start_point.z}")

            # If this point has a lower Z-coordinate, update the lowest_z and store the edge.
            if start_point.z < lowest_z:
                lowest_z = start_point.z
                found_edge = edge

        # Check the Z-coordinate of the end vertex.
        end_vertex = edge.endVertex
        if end_vertex:
            end_point = end_vertex.geometry
            # ui.messageBox(f"End Vertex: {end_point.x}, {end_point.y}, {end_point.z}")

            # If this point has a lower Z-coordinate, update the lowest_z and store the edge.
            if end_point.z < lowest_z:
                lowest_z = end_point.z
                found_edge = edge
    
    return found_edge
 
def connect(part1_name: str, part2_name: str, type):
    app = adsk.core.Application.get()
    ui = app.userInterface
    design = adsk.fusion.Design.cast(app.activeProduct)
    if not design:
        ui.messageBox('No active design', 'No Design')
        return

    rootComp = design.rootComponent
    
    part1_inst = None
    part2_inst = None
    
    found_parts = {}

    for occ in rootComp.occurrences:
        if part1_name+":1" == occ.name:
            for child_occ in occ.childOccurrences:
                if "Frame" in child_occ.name:
                    found_parts[part1_name] = box(child_occ)
                    break
        elif part2_name+":1" == occ.name:
            for child_occ in occ.childOccurrences:
                if "Frame" in child_occ.name:
                    found_parts[part2_name] = box(child_occ)
                    break
    
    part1_inst = found_parts.get(part1_name)
    part2_inst = found_parts.get(part2_name)
    
    if not part1_inst or not part2_inst:
        ui.messageBox(f"Couldn't find both parts to connect. Searched for: '{part1_name}' and '{part2_name}'.")
        return

    # Get proxy faces from box 
    if (type == "Straight"):
        face1_proxy = part1_inst.getBack("BS")
        face2_proxy = part2_inst.getFront("FS")

        if not face1_proxy or not face2_proxy:
            ui.messageBox("Straight Couldn't find faces. Check the names or component structure.")
            return

        # Use proxy faces to create joint 
        geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
            face1_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )
        geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
            face2_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )
        
        if not geo1 or not geo2:
            ui.messageBox("Failed to create joint geometry.")
            return

        joints = rootComp.joints
        jointInput = joints.createInput(geo1, geo2)
        jointInput.setAsRigidJointMotion()
        
        #
        # CODE!!
        #
        jointInput.isFlipped = True
        
        newJoint = joints.add(jointInput)
        if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
            msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
            ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")
    elif (type == "Left"):

        face1_proxy = part1_inst.getBack("BS")
        face2_proxy = part2_inst.getLeft("FS")

        if not face1_proxy or not face2_proxy:
            ui.messageBox("LEFT Couldn't find faces. Check the names or component structure.")
            return

        
        # Create the first joint geometry
        geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
            face1_proxy, find_lowest_edge_on_face(face1_proxy), adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )

        geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
            face2_proxy, find_lowest_edge_on_face(face2_proxy), adsk.fusion.JointKeyPointTypes.MiddleKeyPoint
        )

        if not geo1 or not geo2:
            ui.messageBox("Failed to create joint geometry.")
            return

        joints = rootComp.joints
        jointInput = joints.createInput(geo1, geo2)

        # Now, set the joint motion type. The transform is no longer needed here.
        jointInput.setAsRigidJointMotion()

        jointInput.isFlipped = True
        newJoint = joints.add(jointInput)
        if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
            msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
            ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")
    elif (type == "LeftC"):
        face1_proxy = part1_inst.getFront("BS")
        face2_proxy = part2_inst.getFront("FS")

        if not face1_proxy or not face2_proxy:
            ui.messageBox("Straight Couldn't find faces. Check the names or component structure.")
            return

        # Use proxy faces to create joint 
        geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
            face1_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )
        geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
            face2_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )
        
        if not geo1 or not geo2:
            ui.messageBox("Failed to create joint geometry.")
            return

        joints = rootComp.joints
        jointInput = joints.createInput(geo1, geo2)
        jointInput.setAsRigidJointMotion()
        
        #
        # CODE!!
        #
        jointInput.isFlipped = True
        
        newJoint = joints.add(jointInput)
        if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
            msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
            ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")
    elif (type == "Right"):

        face1_proxy = part1_inst.getBack("BS")
        face2_proxy = part2_inst.getRight("FS")

        if not face1_proxy or not face2_proxy:
            ui.messageBox("LEFT Couldn't find faces. Check the names or component structure.")
            return

        
        # Create the first joint geometry
        geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
            face1_proxy, find_lowest_edge_on_face(face1_proxy), adsk.fusion.JointKeyPointTypes.EndKeyPoint
        )

        geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
            face2_proxy, find_lowest_edge_on_face(face2_proxy), adsk.fusion.JointKeyPointTypes.EndKeyPoint
        )

        if not geo1 or not geo2:
            ui.messageBox("Failed to create joint geometry.")
            return

        joints = rootComp.joints
        jointInput = joints.createInput(geo1, geo2)

        # Now, set the joint motion type. The transform is no longer needed here.
        jointInput.setAsRigidJointMotion()

        jointInput.isFlipped = True
        newJoint = joints.add(jointInput)
        if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
            msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
            ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")
    elif (type == "RightC"):
        face1_proxy = part1_inst.getBack("FS")
        face2_proxy = part2_inst.getFront("FS")

        if not face1_proxy or not face2_proxy:
            ui.messageBox("Straight Couldn't find faces. Check the names or component structure.")
            return

        # Use proxy faces to create joint 
        geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
            face1_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )
        geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
            face2_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
        )
        
        if not geo1 or not geo2:
            ui.messageBox("Failed to create joint geometry.")
            return

        joints = rootComp.joints
        jointInput = joints.createInput(geo1,geo2)
        jointInput.setAsRigidJointMotion()
        
        #
        # CODE!!
        #
        #jointInput.isFlipped = True
        
        newJoint = joints.add(jointInput)
        if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
            msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
            ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")
    elif (type == "UTurn"):
        ui.messageBox("UTurn")
        """
        face1_proxy = part1_inst.getBack("BS")
        face2_proxy = part2_inst.getRight("FS")

        if not face1_proxy or not face2_proxy:
            ui.messageBox("LEFT Couldn't find faces. Check the names or component structure.")
            return

        
        # Create the first joint geometry
        geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
            face1_proxy, find_lowest_edge_on_face(face1_proxy), adsk.fusion.JointKeyPointTypes.EndKeyPoint
        )

        geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
            face2_proxy, find_lowest_edge_on_face(face2_proxy), adsk.fusion.JointKeyPointTypes.EndKeyPoint
        )

        if not geo1 or not geo2:
            ui.messageBox("Failed to create joint geometry.")
            return

        joints = rootComp.joints
        jointInput = joints.createInput(geo1, geo2)

        # Now, set the joint motion type. The transform is no longer needed here.
        jointInput.setAsRigidJointMotion()

        jointInput.isFlipped = True
        newJoint = joints.add(jointInput)
        if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
            msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
            ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")
        """
    elif (type == "UTurnC"):
        ui.messageBox("UTurnC")
    elif (type == "UTurnR"):
        
        ui.messageBox("UTurnR")
#UTurnR
#
def Block_connect(part1_name: str,post_num,post_it, part2_name: str, type="straight"):
    app = adsk.core.Application.get()
    ui = app.userInterface
    design = adsk.fusion.Design.cast(app.activeProduct)
    if not design:
        ui.messageBox('No active design', 'No Design')
        return

    rootComp = design.rootComponent
    
    part1_inst = None
    part2_inst = None
    
    found_parts = {}

    for occ in rootComp.occurrences:
        if len(found_parts) < 2:
            # posts
            if part1_name+":1" == occ.name:
                for child_occ in occ.childOccurrences:
                    if "Posts" in child_occ.name:
                        found_parts[part1_name] = post(child_occ)
                        break
            # block
            elif part2_name+":1" == occ.name:
                for child_occ in occ.childOccurrences:
                    if "Block" in child_occ.name:
                        found_parts[part2_name] = block(child_occ)
                        break
        
    
    part1_inst = found_parts.get(part1_name)
    part2_inst = found_parts.get(part2_name)
    
    if not part1_inst or not part2_inst:
        #ui.messageBox(f"Couldn't find both parts to connect. Searched for: '{part1_name}' and '{part2_name}'.")
        return

    # Get proxy faces from box 
    face1_proxy = part1_inst.getBottom(post_num,post_it)
    face2_proxy = part2_inst.getTop()

    if not face1_proxy or not face2_proxy:
        #ui.messageBox("Couldn't find faces. Check the names or component structure.")
        return

    # Use proxy faces to create joint 
    geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
        face1_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
    )
    geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
        face2_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
    )
    
    if not geo1 or not geo2:
        ui.messageBox("Failed to create joint geometry.")
        return

    joints = rootComp.joints
    jointInput = joints.createInput(geo1, geo2)
    jointInput.setAsRigidJointMotion()
    
    #
    # CODE!!
    #
    jointInput.isFlipped = True
    
    newJoint = joints.add(jointInput)
    if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
        msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
        ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")

def Paver_connect(part1_name: str,post_num,post_it, part2_name: str, type="straight"):
    app = adsk.core.Application.get()
    ui = app.userInterface
    design = adsk.fusion.Design.cast(app.activeProduct)
    if not design:
        ui.messageBox('No active design', 'No Design')
        return

    rootComp = design.rootComponent
    
    part1_inst = None
    part2_inst = None
    
    found_parts = {}

    for occ in rootComp.occurrences:
        if len(found_parts) < 2:
            # posts
            if part1_name+":1" == occ.name:
                for child_occ in occ.childOccurrences:
                    if "Posts" in child_occ.name:
                        found_parts[part1_name] = post(child_occ)
                        break
            # block
            elif part2_name+":1" == occ.name:
                        found_parts[part2_name] = Paver(occ)
                        break
        
    
    part1_inst = found_parts.get(part1_name)
    part2_inst = found_parts.get(part2_name)
    
    if not part1_inst or not part2_inst:
        ui.messageBox(f"Couldn't find both parts to connect. Searched for: '{part1_name}' and '{part2_name}'.")
        return

    # Get proxy faces from box 
    face1_proxy = part1_inst.getBottom(post_num,post_it)
    face2_proxy = part2_inst.getTop()

    if not face1_proxy or not face2_proxy:
        #ui.messageBox("Couldn't find faces. Check the names or component structure.")
        return

    # Use proxy faces to create joint 
    geo1 = adsk.fusion.JointGeometry.createByPlanarFace(
        face1_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
    )
    geo2 = adsk.fusion.JointGeometry.createByPlanarFace(
        face2_proxy, None, adsk.fusion.JointKeyPointTypes.CenterKeyPoint
    )
    
    if not geo1 or not geo2:
        ui.messageBox("Failed to create joint geometry.")
        return

    joints = rootComp.joints
    jointInput = joints.createInput(geo1,geo2)
    jointInput.setAsRigidJointMotion()
    
    #
    # CODE!!
    #
    jointInput.isFlipped = True
    
    newJoint = joints.add(jointInput)
    if not newJoint or newJoint.healthState != adsk.fusion.FeatureHealthStates.HealthyFeatureHealthState:
        msg = newJoint.errorOrWarningMessage if newJoint else "Joint was None"
        ui.messageBox(f"Joint failed:\n{msg}", "Joint Error")

# file sorting
def get_number(file_name):
    """Extracts the leading number from a filename."""
    match = re.match(r'(\d+)_', file_name.split('\\')[-1])
    if match:
        return int(match.group(1))

def run(context):
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        
        design = adsk.fusion.Design.cast(app.activeProduct)
        if not design:
            ui.messageBox('No active design', 'No Design')
            return
        # 
        # Main
        #
        Temp_file_path=r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp"

        post8=0
        post10=0
        post12=0
        post16=0

        # Create an empty set instead of a list
        part_files_set = []

        # Get files and Height data
        for file in os.listdir(Temp_file_path):
                # Check if the file name does NOT end with '.h'
                if file.endswith('.f3d'):
                    # Use .add() to add to a set. Duplicates are automatically ignored.
                    part_files_set.append(file)
                if file.endswith('.h'):
                    # open in case if need OG ramp input (Part list)
                    #h_file = open(file,"r")
                    height=file.strip(".h")
        
        #
        # Set post and place blocks
        #
        # Total height from top of box
        height=int(height)-5.5#+.355 # account for box height plus deck board # RANDO VALYUE

        pavers=0
        block=0
        n = len(part_files_set)
        for i in range(n):
            for j in range(0, n - i - 1):
                num1 = get_number(part_files_set[j])
                num2 = get_number(part_files_set[j + 1])

                # Check if both numbers are valid before comparing
                if num1 is not None and num2 is not None:
                    # Swap if the element found is greater than the next element
                    if num1 > num2:
                        part_files_set[j], part_files_set[j + 1] = part_files_set[j + 1], part_files_set[j]
        #
        # Set connections
        #
        for idx,part in enumerate(part_files_set):

            prev_part = part_files_set[idx - 1] if idx > 0 else None
            next_part = part_files_set[idx + 1] if idx < len(part_files_set) - 1 else None

            if (idx != len(part_files_set)-1):

                if ("UTurn Left" in next_part or "UTurn Right" in next_part):
                    con="UTurn"
                elif ("UTurn Left" in part):
                    con="UTurnC"
                elif ("UTurn Right" in part):
                    con="UTurnR"
                elif ("Left Turn" in next_part):
                    con="Left"
                elif ("Left Turn" in part):
                    con="LeftC"
                elif ("Right Turn" in next_part):
                    con="Right"
                elif ("Right Turn" in part):
                    con="RightC"
                else:
                    con="Straight"

                connect(part.replace(".f3d",""),part_files_set[idx+1].replace(".f3d",""),con)
        
        Total_sum = {}
        #ui.messageBox(f"{part_files_set}") 
        for part in part_files_set:
            #
            # Calulate all boards needed
            #
            current_block_parts = {}
            if "8ft" in part:
                current_block_parts = blocks["8ft"]
            elif "12ft" in part:
                current_block_parts = blocks["12ft"]
            elif "16ft" in part:
                current_block_parts = blocks["16ft"]
            elif "Turn" in part:
                current_block_parts = blocks["Turn"]
            elif "Landing" in part:
                current_block_parts = blocks["Landing"]
            elif "UTurn" in part:
                current_block_parts = blocks["UTurn"]

            for material, count in current_block_parts.items():
                if material in Total_sum:
                    Total_sum[material] += count
                else:
                    Total_sum[material] = count

            user_param = "FP" if part[0] == "0" else "FP_" + part[0]

            # Check if Deck Block or paver and adjust height
            # Using a dictionary to map height conditions to end_type and adjustment

            if height > 8:
                end_type = "Block"
                modifier = -5.5 ## Total block is 7.5 drop is 2 inch
            elif height < 3:
                end_type = "Set"
                modifier = 12.01
            else:
                end_type = "Paver"
                modifier = -2
            
            # Update the user parameter
            userParams = design.userParameters
            param = userParams.itemByName(user_param)
            
            if param:
                if (end_type == "Set"):
                    total_height = 39.5+modifier
                    param.expression = str(modifier)
                else:
                    total_height = 39.5+height+modifier
                    param.expression = str(height+modifier)
                #ui.messageBox(f'Parameter "{user_param}" updated to {height} for {end_type}.')
            else:
                ui.messageBox(f'Parameter "{user_param}" not found.')
            
            #ui.messageBox(f"{part}  {end_type} {height}")
            if (end_type != "set"):
                if ("Landing" in part):
                    for i in range(2):
                        if end_type == "Block":
                            _import_block(app, end_type,part)
                            block+=1
                            if (block==1):
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block")
                            else:
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block ("+str(block-1)+")")
                        elif end_type == "Paver":
                            _import_block(app, end_type,part)
                            pavers+=1
                            if (pavers==1):
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver")
                            else:
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver ("+str(pavers-1)+")")
                if ("Left" in part or "Right" in part):
                    for i in range(4):
                        if end_type == "Block":
                            _import_block(app, end_type,part)
                            block+=1
                            if (block==1):
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block")
                            else:
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block ("+str(block-1)+")")
                        elif end_type == "Paver":
                            _import_block(app, end_type,part)
                            pavers+=1
                            if (pavers==1):
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver")
                            else:
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver ("+str(pavers-1)+")")
                if ("UTurn" in part):
                    for i in range(5):
                        if end_type == "Block":
                            _import_block(app, end_type,part)
                            block+=1
                            if (block==1):
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block")
                            else:
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block ("+str(block-1)+")")
                        elif end_type == "Paver":
                            _import_block(app, end_type,part)
                            pavers+=1
                            if (pavers==1):
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver")
                            else:
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver ("+str(pavers-1)+")")
                if ("8ft" in part):
                    height-=8+.355
                    for i in range(2):
                        if end_type == "Block":
                            _import_block(app, end_type,part)
                            block+=1
                            if (block==1):
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block")
                            else:
                                Block_connect(part.replace(".f3d",""),i+1,part[0],"Deck Block ("+str(block-1)+")")
                        elif end_type == "Paver":
                            _import_block(app, end_type,part)
                            pavers+=1
                            if (pavers==1):
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver")
                            else:
                                Paver_connect(part.replace(".f3d",""),i+1,part[0],"Paver ("+str(pavers-1)+")")

                elif ("12ft" in part):
                    height-=12
                elif ("16ft" in part):
                    height -= 16
            else:
                if ("8ft" in part):
                    height-=8
                elif ("12ft" in part):
                    height-=12
                elif ("16ft" in part):
                    height -= 16
            if ("FP" in part):
                if ("8ft" in part):
                    if total_height <= 48:
                        post8 +=1
                    elif total_height <= 60:
                        post10 +=1
                    elif total_height <= 72:
                        post12 +=1
                    elif total_height <= 96:
                        post8 += 2
                    elif total_height <= 120:
                        post10 += 2
                    elif total_height <= 144:
                        post12 += 2
                    elif total_height <= 196:
                        post16 += 2
                    else:
                        ui.messageBox(f"Height too tall! OVER 16 FEET {total_height}")
                elif ("12ft" in part or "16ft" in part or "Turn" in part or "Landing" in part):
                    if total_height <= 48:
                        post8 +=2
                    elif total_height <= 60:
                        post10 +=2
                    elif total_height <= 72:
                        post12 +=2
                    elif total_height <= 96:
                        post8 += 4
                    elif total_height <= 120:
                        post10 += 4
                    elif total_height <= 144:
                        post12 += 4
                    elif total_height <= 196:
                        post16 += 4
                    else:
                        ui.messageBox(f"Height too tall! OVER 16 FEET {total_height}")
            if ("UTurn" in part):
                    if total_height <= 48:
                        post8 +=3
                    elif total_height <= 60:
                        post10 +=3
                    elif total_height <= 72:
                        post12 +=3
                    elif total_height <= 96:
                        post8 += 5
                    elif total_height <= 120:
                        post10 += 5
                    elif total_height <= 144:
                        post12 += 5
                    elif total_height <= 196:
                        post16 += 5
                    else:
                        ui.messageBox(f"Height too tall! OVER 16 FEET {total_height}")
                
            
        if post8 != 0:
            if "4x4x8" not in Total_sum:
                Total_sum["4x4x8"] = post8
        if post10 != 0:
            if "4x4x10" not in Total_sum:
                Total_sum["4x4x10"] = post10
        if post12 != 0:
            if "4x4x12" not in Total_sum:
                Total_sum["4x4x12"] = post12
        if post16 != 0:
            if "4x4x16" not in Total_sum:
                Total_sum["4x4x16"] = post16

        #
        # Export CSV
        #
        data_for_csv = [Total_sum]
        dicts_to_csv(data_for_csv, r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp\CutList.csv")

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))