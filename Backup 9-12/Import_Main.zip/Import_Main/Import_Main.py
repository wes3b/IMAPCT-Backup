# Fusion360API Python script

import traceback
import adsk.core as core
import adsk.fusion as fusion
import os
import re

import pathlib
THIS_DIR = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp"
temp_destination_dir = r"C:\Users\weshu\OneDrive\Desktop\IMPACT Assets\Temp"
parts_list_files = sorted([os.path.join(temp_destination_dir, f) for f in os.listdir(temp_destination_dir) if f.endswith('.f3d')])
def get_number(file_name):
    """Extracts the leading number from a filename."""
    match = re.match(r'(\d+)_', file_name.split('\\')[-1])
    if match:
        return int(match.group(1))
def import_f3ds(paths: list[str]) -> None:
    app: core.Application = core.Application.get()
    try:
        des: fusion.Design = app.activeProduct
        root: fusion.Component = des.rootComponent

        importMgr: core.ImportManager = app.importManager

        for path in paths:
            importOpt: core.FusionArchiveImportOptions = importMgr.createFusionArchiveImportOptions(
                path,
            )
            importMgr.importToTarget(importOpt , root)
    except:
        app.log('Failed:\n{}'.format(traceback.format_exc()))

def run(context):
    ui: core.UserInterface = None
    try:
        app: core.Application = core.Application.get()
        ui = app.userInterface

        n = len(parts_list_files)
        for i in range(n):
            for j in range(0, n - i - 1):
                num1 = get_number(parts_list_files[j])
                num2 = get_number(parts_list_files[j + 1])

                # Check if both numbers are valid before comparing
                if num1 is not None and num2 is not None:
                    # Swap if the element found is greater than the next element
                    if num1 > num2:
                        parts_list_files[j], parts_list_files[j + 1] = parts_list_files[j + 1], parts_list_files[j]
                # Optional: Handle cases where one or both are None
                # For example, you might want files with no number to be at the end.
                # You could add an 'elif' or 'else' here.

        #ui.messageBox(f"{parts_list_files}")
        import_f3ds(parts_list_files)

    except:
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))

